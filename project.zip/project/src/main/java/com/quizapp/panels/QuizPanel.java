package com.quizapp.panels;

import com.quizapp.QuizAppGUI;
import com.quizapp.model.Question;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class QuizPanel extends JPanel {
    private JLabel questionLabel;
    private JLabel questionNumberLabel;
    private JRadioButton optionA, optionB, optionC, optionD;
    private ButtonGroup optionsGroup;
    private JButton nextButton;
    private List<Question> questions;
    private int currentQuestionIndex;
    private QuizAppGUI gui;
    private int score;
    private Timer timer;
    private JLabel timerLabel;
    private final int timePerQuestion = 15;
    private int timeLeft;
    private final int maxQuestions = 15;
    private JButton endButton;
    private Image backgroundImage;
    private float backgroundDullness = 0.5f;

    public QuizPanel(QuizAppGUI gui, List<Question> questions) {
        this.gui = gui;
        this.questions = questions;

        backgroundImage = new ImageIcon(getClass().getClassLoader().getResource("static/images/question.jpeg")).getImage();

        // Change to null layout for absolute positioning
        setLayout(null);
        setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        // Initialize components
        initializeComponents();
        
        // Add components with fixed positions
        addComponentsWithFixedPositions();

        initializeTimer();
        loadQuestion();
    }

    private void initializeComponents() {
        // Timer Label
        timerLabel = new JLabel("Time Left: " + timePerQuestion + " seconds");
        timerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        timerLabel.setForeground(Color.BLACK);

        // Question Number Label
        questionNumberLabel = new JLabel();
        questionNumberLabel.setFont(new Font("Arial", Font.BOLD, 18));
        questionNumberLabel.setForeground(Color.BLACK);

        // Question Label with fixed size
        questionLabel = new JLabel();
        questionLabel.setFont(new Font("Arial", Font.BOLD, 24));
        questionLabel.setForeground(Color.BLACK);
        questionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        questionLabel.setVerticalAlignment(SwingConstants.CENTER);

        // Options with fixed size
        optionA = createStyledRadioButton();
        optionB = createStyledRadioButton();
        optionC = createStyledRadioButton();
        optionD = createStyledRadioButton();

        optionsGroup = new ButtonGroup();
        optionsGroup.add(optionA);
        optionsGroup.add(optionB);
        optionsGroup.add(optionC);
        optionsGroup.add(optionD);

        // Buttons
        nextButton = createStyledButton("Next");
        endButton = createStyledButton("End Quiz");

        nextButton.addActionListener(e -> handleNextButton());
        endButton.addActionListener(e -> endQuiz());
    }

    private JRadioButton createStyledRadioButton() {
        JRadioButton button = new JRadioButton();
        button.setFont(new Font("Arial", Font.PLAIN, 18));
        button.setForeground(Color.BLACK);
        button.setOpaque(false);
        return button;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setBackground(new Color(255, 217, 102));
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        return button;
    }

    private void addComponentsWithFixedPositions() {
        // Get panel dimensions
        int width = 800;
        int height = 600;
        setPreferredSize(new Dimension(width, height));

        // Timer label position
        timerLabel.setBounds(width / 2 - 100, 30, 200, 30);

        // Question number label position
        questionNumberLabel.setBounds(50, 50, 200, 30);

        // Question label position (centered top)
        questionLabel.setBounds(50, 80, width - 100, 120);

        // Options positions (fixed vertical spacing)
        int optionWidth = width - 200;
        int optionHeight = 40;
        int optionX = 100;
        int startY = 220;
        int optionSpacing = 60;

        optionA.setBounds(optionX, startY, optionWidth, optionHeight);
        optionB.setBounds(optionX, startY + optionSpacing, optionWidth, optionHeight);
        optionC.setBounds(optionX, startY + (optionSpacing * 2), optionWidth, optionHeight);
        optionD.setBounds(optionX, startY + (optionSpacing * 3), optionWidth, optionHeight);

        // Button positions
        int buttonWidth = 200;
        int buttonHeight = 40;
        nextButton.setBounds(width / 2 - buttonWidth - 20, height - 100, buttonWidth, buttonHeight);
        endButton.setBounds(width / 2 + 20, height - 100, buttonWidth, buttonHeight);

        // Add all components
        add(timerLabel);
        add(questionNumberLabel);
        add(questionLabel);
        add(optionA);
        add(optionB);
        add(optionC);
        add(optionD);
        add(nextButton);
        add(endButton);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        // Draw background image to fill the entire panel
        g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        
        // Apply transparency overlay
        g2d.setColor(new Color(255, 255, 255, (int)(backgroundDullness * 255)));
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }

    private void loadQuestion() {
        if (currentQuestionIndex < questions.size() && currentQuestionIndex < maxQuestions) {
            Question question = questions.get(currentQuestionIndex);
            
            // Display the question number before the question text
            String questionText = "<html><div style='width: 600px; text-align: center;'>" +
                                  "Question " + (currentQuestionIndex + 1) + ": " +
                                  question.getQuestionText() + "</div></html>";
            questionLabel.setText(questionText);
            
            optionA.setText(question.getOptionA());
            optionB.setText(question.getOptionB());
            optionC.setText(question.getOptionC());
            optionD.setText(question.getOptionD());
            optionsGroup.clearSelection();
            
            timeLeft = timePerQuestion;
            
            if (timer != null) {
                timer.restart();
            }
        } else {
            endQuiz();
        }
    }


    private void initializeTimer() {
        timeLeft = timePerQuestion;
        timer = new Timer(1000, e -> updateTimer());
        timer.start();
    }

    private void updateTimer() {
        timeLeft--;
        timerLabel.setText("Time Left: " + timeLeft + " seconds");
        
        if (timeLeft <= 0) {
            timer.stop();
            handleNextButton();
        }
    }

    private void handleNextButton() {
        if (isAnswerCorrect()) {
            score++;
        }
        currentQuestionIndex++;
        loadQuestion();
    }

    private boolean isAnswerCorrect() {
        Question currentQuestion = questions.get(currentQuestionIndex);
        String correctAnswer = currentQuestion.getCorrectAnswer();

        if (optionA.isSelected() && optionA.getText().equals(correctAnswer)) return true;
        if (optionB.isSelected() && optionB.getText().equals(correctAnswer)) return true;
        if (optionC.isSelected() && optionC.getText().equals(correctAnswer)) return true;
        return optionD.isSelected() && optionD.getText().equals(correctAnswer);
    }

    private void endQuiz() {
        if (timer != null) {
            timer.stop();
        }
        gui.setScore(score);
        gui.showPanel("Score");
    }

    public void resetQuiz(List<Question> newQuestions) {
        this.questions = newQuestions;
        currentQuestionIndex = 0;
        score = 0;
        timeLeft = timePerQuestion;
        
        if (timer != null) {
            timer.stop();
        }
        timer = new Timer(1000, e -> updateTimer());
        timer.start();
        
        loadQuestion();
    }
}
