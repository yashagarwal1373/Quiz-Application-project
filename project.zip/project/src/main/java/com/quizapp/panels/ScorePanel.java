package com.quizapp.panels;

import com.quizapp.QuizAppGUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ScorePanel extends JPanel {
    private JLabel scoreLabel;
    private Image backgroundImage;

    public ScorePanel(QuizAppGUI gui) {
        // Load the background image
        try {
            backgroundImage = new ImageIcon(getClass().getClassLoader().getResource("static/images/scoree.jpg")).getImage();
        } catch (Exception e) {
            System.out.println("Image not found: " + e.getMessage());
        }

        // Set layout for vertical alignment of components
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        // Add the score label
        scoreLabel = new JLabel("Your Score: ");
        scoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        scoreLabel.setForeground(Color.BLACK); // Set text color to black
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 36)); // Increase font size and set bold
        add(Box.createVerticalGlue()); // Space at the top
        add(scoreLabel);

        // Add the "End" button
        JButton endButton = new JButton("End");
        endButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        endButton.setFont(new Font("Arial", Font.BOLD, 24)); // Increase font size of the button
        endButton.setBackground(Color.DARK_GRAY); // Change background color of the button
        endButton.setForeground(Color.WHITE); // Change text color for contrast
        endButton.setPreferredSize(new Dimension(200, 50)); // Increase button size
        add(Box.createRigidArea(new Dimension(0, 20))); // Space between score and button
        add(endButton);
        add(Box.createVerticalGlue()); // Space at the bottom

        // Button action to return to the login or main menu
        endButton.addActionListener(e -> gui.showPanel("Login"));

        // Add hover effect on the button
        endButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                endButton.setBackground(Color.GRAY); // Change background on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                endButton.setBackground(Color.DARK_GRAY); // Change back to original
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw the background image, scaled to fill the panel
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            // Add a brightening overlay to dull the image
            g.setColor(new Color(255, 255, 255, 100)); // Semi-transparent white overlay
            g.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    public void updateScore(int score) {
        scoreLabel.setText("Your Score: " + score); // Display the score
    }
}
