package com.quizapp.panels;

import com.quizapp.QuizAppGUI;
import javax.swing.*;
import java.awt.*;

public class LoginPanel extends JPanel {
    private Image backgroundImage;
    private float backgroundDullness = 0.5f; // Adjust this value between 0.0f to 1.0f to control dullness

    public LoginPanel(QuizAppGUI gui) {
        // Load the background image
        backgroundImage = new ImageIcon(getClass().getClassLoader().getResource("static/images/login.jpg")).getImage();

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        // Create and style the welcome label
        JLabel welcomeLabel = new JLabel("Welcome to the Quiz!");
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcomeLabel.setForeground(Color.BLACK);
        Font customFont = new Font("Arial", Font.BOLD, 36);
        welcomeLabel.setFont(customFont);

        // Style the login button
        JButton loginButton = new JButton("Login");
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.setFont(new Font("Arial", Font.BOLD, 24));
        
        // Set button colors
        Color customButtonColor = new Color(255, 217, 102);
        loginButton.setBackground(customButtonColor);
        loginButton.setForeground(Color.BLACK);
        
        // Make button opaque and remove border focus
        loginButton.setOpaque(true);
        loginButton.setFocusPainted(false);
        loginButton.setBorderPainted(true);
        
        // Set button size
        loginButton.setPreferredSize(new Dimension(200, 50));
        loginButton.setMaximumSize(new Dimension(200, 50));
        
        // Add padding around components
        int padding = 40;
        
        // Add components to the panel with improved spacing
        add(Box.createVerticalGlue());
        add(Box.createRigidArea(new Dimension(0, padding)));
        add(welcomeLabel);
        add(Box.createRigidArea(new Dimension(0, padding)));
        add(loginButton);
        add(Box.createRigidArea(new Dimension(0, padding)));
        add(Box.createVerticalGlue());

        // Button action
        loginButton.addActionListener(e -> gui.showPanel("Rules"));
        
        // Hover effect with darker shade
        loginButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                loginButton.setBackground(new Color(255, 200, 51));
                loginButton.setForeground(Color.BLACK);
                loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                loginButton.setBackground(customButtonColor);
                loginButton.setForeground(Color.BLACK);
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g;
        
        // Draw the background image
        g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        
        // Create a semi-transparent white overlay to dull the image
        g2d.setColor(new Color(255, 255, 255, (int)(backgroundDullness * 255)));
        g2d.fillRect(0, 0, getWidth(), getHeight());
        
        // Optional: Add a slight darkening overlay for better contrast
        g2d.setColor(new Color(0, 0, 0, 30)); // Very slight black overlay
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }
}