package com.quizapp.panels;

import com.quizapp.QuizAppGUI;
import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class RulesPanel extends JPanel {
    private Image backgroundImage;
    private static final String RULES_TEXT = 
        "1. Each question has one correct answer.\n" +
        "2. No time limit.\n" +
        "3. Enjoy the quiz!\n" +
        "4. Please read each question carefully.\n" +
        "5. Your score will be displayed at the end.\n" +
        "6. You can review your answers after finishing.\n" +
        "7. Have fun and good luck!";
    private static final Color TRANSPARENT_COLOR = new Color(0, 0, 0, 0);

    public RulesPanel(QuizAppGUI gui) {
        // Load the background image
        URL imageUrl = getClass().getClassLoader().getResource("static/images/Ruless.jpg");
        if (imageUrl == null) {
            System.err.println("Background image not found at specified path: static/images/Ruless.jpg");
            setBackground(Color.LIGHT_GRAY);
        } else {
            backgroundImage = new ImageIcon(imageUrl).getImage();
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            initComponents(gui);
        }

        // Set preferred size for the panel
        setPreferredSize(new Dimension(800, 600)); // Adjust as needed
    }

    private void initComponents(QuizAppGUI gui) {
        // Center the components
        JLabel rulesLabel = new JLabel("Quiz Rules:");
        rulesLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        rulesLabel.setFont(new Font("Arial", Font.BOLD, 32)); // Increased font size for the rules label

        JTextArea rulesText = new JTextArea(RULES_TEXT);
        rulesText.setAlignmentX(Component.CENTER_ALIGNMENT);
        rulesText.setEditable(false);
        rulesText.setBackground(TRANSPARENT_COLOR);
        rulesText.setBorder(null);
        rulesText.setFont(new Font("Arial", Font.BOLD, 20)); // Increased and bold font for rules text

        // Wrap JTextArea in a JScrollPane
        JScrollPane scrollPane = new JScrollPane(rulesText);
        scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);
        scrollPane.setPreferredSize(new Dimension(400, 150)); // Increased size for the scroll pane
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        JButton startQuizButton = new JButton("Start Quiz");
        startQuizButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        startQuizButton.setFont(new Font("Arial", Font.BOLD, 24)); // Increased font size for button

        // Add components to the panel
        add(Box.createVerticalGlue());
        add(rulesLabel);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(scrollPane);
        add(Box.createRigidArea(new Dimension(0, 20)));
        add(startQuizButton);
        add(Box.createVerticalGlue());

        // Button action
        startQuizButton.addActionListener(e -> startQuiz(gui));
    }

    private void startQuiz(QuizAppGUI gui) {
        gui.showPanel("Quiz");
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw the background image, scaled to fill the panel
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);

            // Add a brightening overlay
            g.setColor(new Color(255, 255, 255, 100)); // Semi-transparent white
            g.fillRect(0, 0, getWidth(), getHeight());
        } else {
            // Fill with a color if the image is not loaded
            g.setColor(Color.LIGHT_GRAY);
            g.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}
