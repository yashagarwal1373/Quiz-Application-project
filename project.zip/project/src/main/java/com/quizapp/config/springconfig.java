package com.quizapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import com.quizapp.service.QuestionService;

@Configuration
@ComponentScan(basePackages = "com.quizapp")
public class springconfig {

    @Bean
    public QuestionService questionService() {
        return new QuestionService();
    }
}
