package com.quizapp;

public class Rules {
    public void showRules() {
        System.out.println("Quiz Rules:");
        System.out.println("1. Each question has four options.");
        System.out.println("2. Only one option is correct.");
        System.out.println("3. You will receive 1 point for each correct answer.");
        System.out.println("4. There is no negative marking.");
        System.out.println("5. Try to answer all the questions.");
    }
}
