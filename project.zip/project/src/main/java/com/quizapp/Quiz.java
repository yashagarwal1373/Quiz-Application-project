package com.quizapp;

import com.quizapp.model.Question;
import com.quizapp.service.QuestionService;

import java.util.List;

public class Quiz {
    private List<Question> questions;
    private int currentQuestionIndex;
    private int score;

    public Quiz() {
        // Initialize the QuestionService to fetch and retrieve questions
        QuestionService questionService = new QuestionService();
        questionService.fetchAndStoreQuestions(); // Fetch and store questions from API if needed
        this.questions = questionService.getAllQuestions(); // Load questions from database

        this.currentQuestionIndex = 0;
        this.score = 0;
    }

    public boolean hasNextQuestion() {
        return currentQuestionIndex < questions.size();
    }

    public Question getNextQuestion() {
        if (hasNextQuestion()) {
            return questions.get(currentQuestionIndex++);
        }
        return null;
    }

    public void checkAnswer(String userAnswer) {
        Question currentQuestion = questions.get(currentQuestionIndex - 1); // Get the last shown question
        if (currentQuestion.getCorrectAnswer().equalsIgnoreCase(userAnswer)) {
            score++;
        }
    }

    public int getScore() {
        return score;
    }

    public int getTotalQuestions() {
        return questions.size();
    }

    public void resetQuiz() {
        currentQuestionIndex = 0;
        score = 0;
    }
}
