package com.quizapp;

import com.quizapp.model.Question;
import com.quizapp.panels.LoginPanel;
import com.quizapp.panels.QuizPanel;
import com.quizapp.panels.RulesPanel;
import com.quizapp.panels.ScorePanel;
import com.quizapp.service.QuestionService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class QuizAppGUI extends JFrame {
    private ScorePanel scorePanel;
    private QuizPanel quizPanel;
    private int score;
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private QuestionService questionService;

    public QuizAppGUI() {
        setTitle("Quiz Application");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize layout and main panel
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Initialize QuestionService to fetch questions
        questionService = new QuestionService();
        List<Question> questions = questionService.getAllQuestions();

        // Initialize all panels and add them to the main panel
        initializePanels(questions);

        // Add the main panel to the frame
        add(mainPanel);
        
        // Display the login panel by default
        showPanel("Login");
    }

    private void initializePanels(List<Question> questions) {
        // Create and add the login panel
        LoginPanel loginPanel = new LoginPanel(this);
        mainPanel.add(loginPanel, "Login");

        // Create and add the rules panel
        RulesPanel rulesPanel = new RulesPanel(this);
        mainPanel.add(rulesPanel, "Rules");

        // Create and add the quiz panel with questions
        quizPanel = new QuizPanel(this, questions);
        mainPanel.add(quizPanel, "Quiz");

        // Create and add the score panel
        scorePanel = new ScorePanel(this);
        mainPanel.add(scorePanel, "Score");
    }

    // Method to switch between different panels
    public void showPanel(String panelName) {
        cardLayout.show(mainPanel, panelName);
    }

    // Set the score and update it in the score panel
    public void setScore(int score) {
        this.score = score;
        if (scorePanel != null) {
            scorePanel.updateScore(score); // Ensure scorePanel is not null before updating
        }
    }

    // Reset the quiz with fresh questions and display the quiz panel
    public void restartQuiz() {
        List<Question> newQuestions = questionService.getAllQuestions();  // Fetch fresh questions from the database

        if (newQuestions != null && !newQuestions.isEmpty()) {
            quizPanel.resetQuiz(newQuestions);                            // Reset the quiz panel with the new list of questions
            showPanel("Quiz");                                            // Show the quiz panel
        } else {
            System.out.println("No questions available to start the quiz."); // Handle the case where no questions are returned
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            QuizAppGUI gui = new QuizAppGUI();
            gui.setVisible(true);
        });
    }
}
