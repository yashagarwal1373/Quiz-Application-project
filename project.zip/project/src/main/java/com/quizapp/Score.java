package com.quizapp;

public class Score {
    private int correctAnswers;

    public void incrementCorrectAnswers() {
        correctAnswers++;
    }

    public int getCorrectAnswers() {
        return correctAnswers;
    }

    public void resetScore() {
        correctAnswers = 0;
    }
}
