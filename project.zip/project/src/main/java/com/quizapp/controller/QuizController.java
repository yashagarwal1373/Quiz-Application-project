package com.quizapp.controller;

import com.quizapp.model.Question;
import com.quizapp.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/questions")
public class QuizController {

    private final QuestionService questionService;

    @Autowired
    public QuizController(QuestionService questionService) {
        this.questionService = questionService;
    }

    // Endpoint to fetch questions from the internet and store them in the database
    @GetMapping("/fetch")
    public String fetchQuestions() {
        try {
            questionService.fetchAndStoreQuestions();
            return "Questions fetched and stored successfully!";
        } catch (Exception e) {
            e.printStackTrace();
            return "Failed to fetch and store questions.";
        }
    }

    // Endpoint to get all questions from the database
    @GetMapping
    public List<Question> getQuestions() {
        return questionService.getAllQuestions();
    }
}
