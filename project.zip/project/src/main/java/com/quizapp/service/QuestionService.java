package com.quizapp.service;

import com.quizapp.database.DatabaseConnection;
import com.quizapp.model.Question;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class QuestionService {
    private static final String API_URL = "https://opentdb.com/api.php?amount=50&category=18&type=multiple";

    // Fetches questions from the API and stores them in the database
    public void fetchAndStoreQuestions() {
        try {
            // Fetch JSON data from API
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder content = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            conn.disconnect();

            // Parse JSON and store questions
            JSONObject json = new JSONObject(content.toString());
            JSONArray resultsArray = json.getJSONArray("results");

            for (int i = 0; i < resultsArray.length(); i++) {
                JSONObject result = resultsArray.getJSONObject(i);

                // Parse question details
                Question question = new Question();
                question.setQuestionText(result.getString("question"));

                JSONArray incorrectAnswers = result.getJSONArray("incorrect_answers");
                question.setOptionA(incorrectAnswers.getString(0));
                question.setOptionB(incorrectAnswers.getString(1));
                question.setOptionC(incorrectAnswers.getString(2));
                question.setOptionD(result.getString("correct_answer"));
                question.setCorrectAnswer(result.getString("correct_answer"));

                // Store the question in the database
                saveQuestionToDatabase(question);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Saves a single question to the database
    private void saveQuestionToDatabase(Question question) {
        String query = "INSERT INTO questions (question_text, optionA, optionB, optionC, optionD, correctAnswer) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, question.getQuestionText());
            statement.setString(2, question.getOptionA());
            statement.setString(3, question.getOptionB());
            statement.setString(4, question.getOptionC());
            statement.setString(5, question.getOptionD());
            statement.setString(6, question.getCorrectAnswer());

            statement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Retrieves all questions from the database
    public List<Question> getAllQuestions() {
        List<Question> questions = new ArrayList<>();
        String query = "SELECT * FROM questions";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Question question = new Question();
                question.setQuestionText(resultSet.getString("question_text"));
                question.setOptionA(resultSet.getString("optionA"));
                question.setOptionB(resultSet.getString("optionB"));
                question.setOptionC(resultSet.getString("optionC"));
                question.setOptionD(resultSet.getString("optionD"));
                question.setCorrectAnswer(resultSet.getString("correctAnswer"));

                questions.add(question);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return questions;
    }
}
